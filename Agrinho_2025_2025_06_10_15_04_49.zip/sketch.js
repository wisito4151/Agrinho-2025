let gallina; // Objeto para la gallina
let coches = []; // Array para almacenar los coches
let velocidadAutopista = 3; // Velocidad a la que se "mueve" la autopista
let puntuacion = 0;
let gameOver = false;

// Variables para la autopista (líneas de la carretera)
let lineasCarretera = [];
let espaciadoLineas = 80;
let anchoLinea = 10;
let altoLinea = 40;

function preload() {
  // Carga tu imagen de gallina aquí si la tienes.
  // gallinaImg = loadImage('assets/gallina.png');
  // cocheImg1 = loadImage('assets/coche1.png');
  // cocheImg2 = loadImage('assets/coche2.png');
}

function setup() {
  createCanvas(400, 600); // Tamaño de la ventana de juego
  rectMode(CENTER); // Para dibujar rectángulos desde su centro (útil para la gallina)
  imageMode(CENTER); // Para dibujar imágenes desde su centro (si usas imágenes)

  // Inicializa la gallina
  gallina = {
    x: width / 2,
    y: height - 50,
    ancho: 40,
    alto: 40,
  };

  // Inicializa las líneas de la carretera
  for (let i = 0; i < height / espaciadoLineas + 2; i++) {
    lineasCarretera.push({
      y: i * espaciadoLineas
    });
  }

  setInterval(crearCoche, 1000); // Crea un coche cada segundo
}

function draw() {
  background(50, 50, 50); // Fondo gris oscuro para la carretera

  if (gameOver) {
    mostrarFinDeJuego();
    return; // Detiene el resto del bucle draw
  }

  // Actualiza y dibuja las líneas de la carretera
  for (let i = 0; i < lineasCarretera.length; i++) {
    let linea = lineasCarretera[i];
    linea.y += velocidadAutopista;
    if (linea.y > height + espaciadoLineas / 2) {
      linea.y = -espaciadoLineas / 2; // Reinicia la línea arriba
    }
    fill(200, 200, 0); // Color amarillo para las líneas
    noStroke();
    rect(width / 2, linea.y, anchoLinea, altoLinea);
  }

  // Dibuja la gallina
  // Si usas imagen: image(gallinaImg, gallina.x, gallina.y, gallina.ancho, gallina.alto);
  fill(255, 255, 0); // Color amarillo para la gallina
  ellipse(gallina.x, gallina.y, gallina.ancho, gallina.alto); // Dibuja la gallina como un círculo

  // Mueve la gallina con las flechas
  if (keyIsDown(LEFT_ARROW) && gallina.x > gallina.ancho / 2) {
    gallina.x -= 5;
  }
  if (keyIsDown(RIGHT_ARROW) && gallina.x < width - gallina.ancho / 2) {
    gallina.x += 5;
  }
  if (keyIsDown(UP_ARROW) && gallina.y > gallina.alto / 2) {
    gallina.y -= 5;
  }
  if (keyIsDown(DOWN_ARROW) && gallina.y < height - gallina.alto / 2) {
    gallina.y += 5;
  }

  // Actualiza y dibuja los coches
  for (let i = coches.length - 1; i >= 0; i--) {
    let coche = coches[i];

    // Mueve el coche hacia abajo (simulando que la gallina avanza)
    coche.y += coche.velocidad + velocidadAutopista;

    // Dibuja el coche
    fill(coche.colorR, coche.colorG, coche.colorB);
    rect(coche.x, coche.y, coche.ancho, coche.alto);

    // Si el coche está fuera de la pantalla, elimínalo y aumenta la puntuación
    if (coche.y > height + coche.alto / 2) {
      coches.splice(i, 1);
      puntuacion++; // Gana un punto por cada coche evitado
      // Aumenta la velocidad gradualmente
      if (puntuacion % 10 === 0 && velocidadAutopista < 10) {
        velocidadAutopista += 0.5;
      }
    }

    // Comprueba colisión entre la gallina y el coche
    if (
      abs(gallina.x - coche.x) < (gallina.ancho / 2 + coche.ancho / 2) &&
      abs(gallina.y - coche.y) < (gallina.alto / 2 + coche.alto / 2)
    ) {
      gameOver = true; // Fin del juego
    }
  }

  // Muestra la puntuación
  fill(255);
  textSize(24);
  textAlign(LEFT, TOP);
  text('Puntuación: ' + puntuacion, 10, 10);
}

function crearCoche() {
  // Crea un coche en una posición aleatoria en la parte superior
  let carX = random(width * 0.2, width * 0.8); // Para evitar que aparezcan muy pegados a los bordes
  let carY = -50; // Empieza fuera de la pantalla
  let carWidth = random(50, 80);
  let carHeight = random(80, 120);
  let carSpeed = random(2, 6); // Velocidad inicial de los coches
  let carColor = [random(0, 255), random(0, 255), random(0, 255)]; // Color aleatorio

  // Asegura que el coche no aparezca justo encima de otro existente (simple check)
  let tooClose = false;
  for (let i = 0; i < coches.length; i++) {
    let existingCar = coches[i];
    if (dist(carX, carY, existingCar.x, existingCar.y) < 150) { // Distancia mínima entre coches
      tooClose = true;
      break;
    }
  }

  if (!tooClose) {
    coches.push({
      x: carX,
      y: carY,
      ancho: carWidth,
      alto: carHeight,
      velocidad: carSpeed,
      colorR: carColor[0],
      colorG: carColor[1],
      colorB: carColor[2],
    });
  }
}

function mostrarFinDeJuego() {
  background(0, 0, 0, 180); // Fondo oscuro semitransparente
  fill(255);
  textSize(48);
  textAlign(CENTER, CENTER);
  text('¡Fin del Juego!', width / 2, height / 2 - 40);
  textSize(32);
  text('Puntuación: ' + puntuacion, width / 2, height / 2 + 20);
  textSize(20);
  text('Presiona ESPACIO para reiniciar', width / 2, height / 2 + 80);
}

function keyPressed() {
  if (gameOver && keyCode === 32) { // 32 es el código para la barra espaciadora
    resetearJuego();
  }
}

function resetearJuego() {
  gallina.x = width / 2;
  gallina.y = height - 50;
  coches = [];
  puntuacion = 0;
  velocidadAutopista = 3;
  gameOver = false;
  loop(); // Reanuda el bucle draw
}dsa